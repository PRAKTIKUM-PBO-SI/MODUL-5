package Perpustakaan;

/**
 *
 * @author achmad
 */
public class ValidasiInputException extends Exception{
    public ValidasiInputException (String message){
        super(message);
    }
    }
    