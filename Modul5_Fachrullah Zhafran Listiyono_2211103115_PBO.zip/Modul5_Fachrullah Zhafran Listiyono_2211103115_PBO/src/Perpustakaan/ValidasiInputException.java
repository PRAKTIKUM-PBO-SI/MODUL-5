package Perpustakaan;

/**
 *
 * @author Fachrullah Zhafran Listiyono_2211103115
 */
public class ValidasiInputException extends Exception {

    public ValidasiInputException(String message) {
        super(message);
    }
}
