/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package latihanp10Rhojay;

/**
 *
 * @author dell G7
 */
public class latihanp10Rhojay {

    public static void main(String[] args) {
        
    }
    
}
