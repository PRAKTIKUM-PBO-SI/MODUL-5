
package latihanexception;

/**
2211103067
* Teddy Putratama
*07C
 */
 public class Buku {
    private String judul;
    private String pengarang;
    private String isbn;
    private int tahunTerbit;
    private double hargaBuku;
    private String kategori;

    public Buku(String judul, String pengarang, String isbn, String kategori, String kategori1, String kategori2) throws ValidasiInputException {
        if (judul.isEmpty()) throw new ValidasiInputException("Judul buku tidak boleh kosong!");
        if (pengarang.isEmpty()) throw new ValidasiInputException("Pengarang tidak boleh kosong!");
        if (!isbn.matches("\\d{13}")) throw new ValidasiInputException("ISBN harus 13 digit angka!");
        if (String.valueOf(tahunTerbit).length() != 4) throw new ValidasiInputException("Tahun terbit harus 4 digit angka!");
        if (hargaBuku <= 0) throw new ValidasiInputException("Harga buku harus lebih besar dari 0!");
        if (kategori.isEmpty()) throw new ValidasiInputException("Kategori buku tidak boleh kosong!");

        this.judul = judul;
        this.pengarang = pengarang;
        this.isbn = isbn;
        this.tahunTerbit = tahunTerbit;
        this.hargaBuku = hargaBuku;
        this.kategori = kategori;
    }

    public String getJudul() { return judul; }
    public String getPengarang() { return pengarang; }
    public String getIsbn() { return isbn; }
    public int getTahunTerbit() { return tahunTerbit; }
    public double getHargaBuku() { return hargaBuku; }
    public String getKategori() { return kategori; }
}

