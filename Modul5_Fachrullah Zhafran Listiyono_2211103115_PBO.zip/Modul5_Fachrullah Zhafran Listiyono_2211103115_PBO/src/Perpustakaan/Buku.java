package Perpustakaan;

/**
 *
 * @author Fachrullah
 */
public class Buku {

    private String judul;
    private String pengarang;
    private String isbn;
    private int tahunTerbit;
    private double harga;
    private String kategori;

    public Buku(String judul, String pengarang, String isbn, int tahunTerbit, double harga, String kategori) throws ValidasiInputException {
        if (judul.isEmpty()) {
            throw new ValidasiInputException("Judul buku tidak boleh kosong!");
        }
        if (pengarang.isEmpty()) {
            throw new ValidasiInputException("Pengarang tidak boleh kosong!");
        }
        if (!isbn.matches("\\d{13}")) {
            throw new ValidasiInputException("ISBN harus 13 digit angka!");
        }
        if (String.valueOf(tahunTerbit).length() != 4) {
            throw new ValidasiInputException("Tahun terbit harus berupa angka 4 digit!");
        }
        if (harga <= 0) {
            throw new ValidasiInputException("Harga buku harus angka positif!");
        }
        if (kategori.isEmpty()) {
            throw new ValidasiInputException("Kategori buku tidak boleh kosong!");
        }

        this.judul = judul;
        this.pengarang = pengarang;
        this.isbn = isbn;
        this.tahunTerbit = tahunTerbit;
        this.harga = harga;
        this.kategori = kategori;
    }

    public String getJudul() {
        return judul;
    }

    public String getPengarang() {
        return pengarang;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getTahunTerbit() {
        return tahunTerbit;
    }

    public double getHarga() {
        return harga;
    }

    public String getKategori() {
        return kategori;
    }
}
