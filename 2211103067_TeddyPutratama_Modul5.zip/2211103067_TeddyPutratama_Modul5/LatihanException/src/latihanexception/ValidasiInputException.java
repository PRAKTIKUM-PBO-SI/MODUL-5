
package latihanexception;

/**
 *
 * @author Asus
 */
public class ValidasiInputException extends Exception {

    public ValidasiInputException(String message) {
        super(message);
    }
}
