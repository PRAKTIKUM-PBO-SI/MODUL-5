/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihanp10Rhojay;

/**
 * @author Rhojay alfirdaus 2311103121

 */
public class ValidasiInputException extends Exception {

    public ValidasiInputException(String message) {
        super(message);
    }
}
